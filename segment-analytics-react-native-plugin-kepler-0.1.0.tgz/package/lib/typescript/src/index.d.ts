import { createClient as baseCreateClient } from '@segment/analytics-react-native';
export declare const createClient: typeof baseCreateClient;
export { KeplerUUIDProvider } from './uuid';
export { KeplerPersistor } from './storage';
//# sourceMappingURL=index.d.ts.map