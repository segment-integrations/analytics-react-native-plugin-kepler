import { UUIDProvider } from '@segment/analytics-react-native';
export declare const KeplerUUIDProvider: UUIDProvider;
//# sourceMappingURL=uuid.d.ts.map