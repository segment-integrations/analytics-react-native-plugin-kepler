import { Persistor } from '@segment/analytics-react-native';
export declare const KeplerPersistor: Persistor;
//# sourceMappingURL=storage.d.ts.map