import { DeviceInfoProvider } from '@segment/analytics-react-native';
export declare const deviceInfoProvider: DeviceInfoProvider;
//# sourceMappingURL=device-info.d.ts.map