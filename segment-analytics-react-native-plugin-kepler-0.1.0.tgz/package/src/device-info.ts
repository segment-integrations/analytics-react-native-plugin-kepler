import DeviceInfo from '@amzn/react-native-device-info';
import { getApplicationName, getVersion, getBuildNumber, getBundleId, getSystemVersion, getModel } from "@amzn/react-native-device-info";
import { getCountry, getTimeZone } from '@amzn/react-native-localize';
import { DeviceInfoProvider } from '@segment/analytics-react-native';

export const deviceInfoProvider: DeviceInfoProvider = async (config) => {
  config.collectDeviceId;
  const applicationName =  getApplicationName();
  const applicationVersion = getVersion();
  const buildNumber = getBuildNumber();
  const bundleId = getBundleId();
  const osVersion = getSystemVersion();
  const model = getModel();
  const country = getCountry(); 
  const timezone = getTimeZone();
  // Async calls
  // let manufacturer = '';
  // let deviceName = '';
  // let deviceId = '';
  // let osName = '';
  

  const osName = await DeviceInfo.getBaseOs();
  const manufacturer = await DeviceInfo.getManufacturer();
  const deviceName = await DeviceInfo.getDeviceName();
  const deviceId = config.collectDeviceId
    ? await DeviceInfo.getUniqueId()
    : undefined;

  const deviceType = await DeviceInfo.getDeviceType();
  const buildNumber2 = await DeviceInfo.getBuildNumber();
  console.log('**********buildNumberDeviceInfo', buildNumber2);
  // const osNamePromise = DeviceInfo.getBaseOs();
  // const manufacturerPromise = DeviceInfo.getManufacturer();
  // const deviceNamePromise = DeviceInfo.getDeviceName();
  // const deviceIdPromise = config.collectDeviceId
  //   ? DeviceInfo.getUniqueId()
  //   : undefined;

  // await Promise.allSettled([
  //   osNamePromise,
  //   manufacturerPromise,
  //   deviceNamePromise,
  //   deviceIdPromise,
  // ]).then(
  //   ([osNamePromise, manufacturerResult, deviceNameResult, deviceIdResult]) => {
  //     if (osNamePromise.status === 'fulfilled') {
  //       osName = osNamePromise.value;
  //     }
  //     if (manufacturerResult.status === 'fulfilled') {
  //       manufacturer = manufacturerResult.value;
  //     }
  //     if (deviceNameResult.status === 'fulfilled') {
  //       deviceName = deviceNameResult.value;
  //     }
  //     if (deviceIdResult.status === 'fulfilled' && deviceIdResult.value) {
  //       deviceId = deviceIdResult.value;
  //     }
  //   }
  // );

  return {
    appName: applicationName,
    appVersion: applicationVersion,
    buildNumber: buildNumber,
    bundleId: bundleId,
    locale: country, // TODO
    networkType: 'wifi', // TODO
    osName: osName,
    osVersion: osVersion,
    screenHeight: 0, // TODO
    screenWidth: 0, // TODO
    timezone: timezone, // TODO
    manufacturer: manufacturer,
    model: model,
    deviceName: deviceName,
    deviceType: deviceType,
    deviceId: deviceId,
  };
};